# update falang_content original_text allow null
ALTER TABLE `#__falang_content` MODIFY `original_text` mediumtext DEFAULT NULL;